# ✅ Installation Checklist - AGUADA v2.1.0

## Pré-Instalação
- [ ] Docker 20.10+ instalado: `docker --version`
- [ ] Docker Compose 2.0+ instalado: `docker-compose --version`
- [ ] Mínimo 5GB disco disponível: `df -h`
- [ ] Portas 80, 443, 3000, 3001, 5432, 6379 livres
- [ ] Conexão internet funcional

## Instalação
- [ ] Pacote extraído com sucesso
- [ ] Diretório `aguada/` criado
- [ ] Permissões corretas: `chmod +x deploy-automatic.sh`
- [ ] Script de deploy executado: `bash deploy-automatic.sh`
- [ ] Todos 5 containers iniciados: `docker-compose ps`

## Validação
- [ ] Health check passou: `curl http://localhost:3000/api/health`
- [ ] 8/8 testes passaram: `./test-sistema.sh`
- [ ] Dashboard carrega: http://localhost
- [ ] API responde: http://localhost:3000/api/sensors
- [ ] Grafana acessa: http://localhost:3001

## Pós-Instalação
- [ ] Senha Grafana alterada (default: admin/admin)
- [ ] Senha Database alterada (se necessário)
- [ ] Backup database realizado
- [ ] SSL/HTTPS configurado (produção)
- [ ] Firewall configurado

## Integração Sensores
- [ ] ESP32 sensor nodes identificados
- [ ] Gateway USB conectado (se aplicável)
- [ ] Firmware flasheado nos devices
- [ ] Primeira leitura recebida em `/api/readings/latest`
- [ ] Dados visíveis no dashboard

## Operação
- [ ] Sistema rodando por 1+ hora sem erros
- [ ] Alertas configurados (se aplicável)
- [ ] Monitoramento ativo (Grafana dashboards)
- [ ] Backups automáticos configurados (opcional)
- [ ] Logs sendo mantidos

## Segurança (Produção)
- [ ] Senhas default alteradas
- [ ] Credenciais removidas de `.env` versionado
- [ ] SSL/HTTPS ativo
- [ ] Firewall restringindo acesso
- [ ] VPN/Proxy reverso em frente (recomendado)

---

Data de Conclusão: _______  
Responsável: _______  
Observações: _______
