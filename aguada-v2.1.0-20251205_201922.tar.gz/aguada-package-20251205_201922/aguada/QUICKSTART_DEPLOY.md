# 🚀 AGUADA v2.1.0 - Quick Deploy Guide

## Sistema Pronto para Produção

Este pacote contém o sistema AGUADA completo e testado. Siga os passos abaixo para deploy.

### 📋 Pré-requisitos

- Docker 20.10+
- Docker Compose 2.0+
- Git (opcional, para versionamento)
- 5GB espaço livre em disco

### 🚀 Deploy Rápido (3 passos)

```bash
# 1. Extrair e navegar
tar xzf aguada-v2.1.0-*.tar.gz
cd aguada

# 2. Executar deploy automático
bash deploy-automatic.sh

# 3. Acessar sistema
# Dashboard:  http://localhost
# API:        http://localhost:3000/api
# Grafana:    http://localhost:3001
```

### 🔒 Deploy Seguro (com SSL)

```bash
bash deploy-automatic.sh --secure --backup
```

### ✅ Validar Deploy

```bash
# Executar suite de testes
./test-sistema.sh

# Todos os 8 testes devem passar ✓
```

### 📖 Documentação Completa

- `DEPLOYMENT.md` - Guia detalhado de deploy
- `docs/RULES.md` - Especificação técnica do sistema
- `backend/README.md` - API documentation
- `firmware/*/README.md` - Firmware ESP32 notes

### 🔧 Troubleshooting

**Erro: "Docker daemon não está rodando"**
```bash
sudo systemctl start docker
sudo systemctl enable docker
```

**Erro: "Port already in use"**
```bash
# Liberar porta
sudo lsof -i :3000
sudo kill -9 <PID>
```

**Erro: "Database connection failed"**
```bash
# Aguardar mais tempo
docker-compose logs postgres
docker-compose ps
```

### 📊 Dados Iniciais

O sistema inicia com dados de exemplo. Para usar dados reais:

```bash
# Restaurar backup
docker-compose exec postgres psql -U aguada -d aguada < seu_backup.sql

# Ou conectar sensores ESP32 via USB
# Verificar em: http://localhost/aguada
```

### 🔐 Segurança

**IMPORTANTE:** Altere credenciais padrão em PRODUÇÃO

```bash
# Grafana (padrão: admin/admin)
http://localhost:3001 → Admin → Change Password

# Database (padrão: aguada_user)
docker-compose exec postgres psql -U aguada -c \
  "ALTER USER aguada_user PASSWORD 'nova_senha';"
```

### 📞 Suporte

Para problemas, consulte:
- `DEPLOYMENT.md` - Guia completo
- `docs/SETUP.md` - Guia de configuração avançada
- Logs: `docker-compose logs -f backend`

---

**Sistema AGUADA v2.1.0**  
Validado e pronto para produção ✅
